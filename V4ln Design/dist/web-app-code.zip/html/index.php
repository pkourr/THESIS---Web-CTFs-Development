<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Example Page</title>
	<link href="assets/style.css" rel="stylesheet" />
</head>
<body>
	<?php echo(file_get_contents('../flag.txt', true)); ?>
	<script src="assets/script.js"></script>
</body>
</html>
