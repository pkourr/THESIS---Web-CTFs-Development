// Example Static JavaScript file
