#!/usr/bin/env python3
# CTFLib Challenge

import os
import secrets
from flask import Flask, render_template


# Load flag from file if exists
flag = 'CTFLIB{example-flag}'
if os.path.isfile('flag.txt'):
	with open('flag.txt', 'r') as f:
		flag = f.read().strip()


# Initialise Flask App
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('APP_SECRET_KEY', secrets.token_hex(32)).strip()


# App Route
@app.route('/')
def index():
    return render_template('index.html', flag=flag)


if __name__ == "__main__":
	app.run(host="0.0.0.0", port=os.getenv('APP_PORT', 4242), debug=False)
